const authentication = require('../authentication');

const test = {
  authentication: authentication,
  beforeRequest: [
  ],
  afterResponse: [
  ],
  searches: {
  },
  creates: {
  },
  triggers: {
  }
};

module.exports = test;
